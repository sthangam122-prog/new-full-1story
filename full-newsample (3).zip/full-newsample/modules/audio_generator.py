from gtts import gTTS
import os
from typing import Dict, Any, List, Optional
import hashlib


class AudioGenerator:
    def __init__(self, output_dir: str = "output/audio"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        self.voice_options = {
            "en-us": {"name": "English (US)", "lang": "en", "tld": "com"},
            "en-uk": {"name": "English (UK)", "lang": "en", "tld": "co.uk"},
            "en-au": {"name": "English (Australian)", "lang": "en", "tld": "com.au"},
            "en-in": {"name": "English (Indian)", "lang": "en", "tld": "co.in"}
        }
    
    def get_available_voices(self) -> Dict[str, str]:
        return {key: value["name"] for key, value in self.voice_options.items()}
    
    def _generate_unique_filename(self, text: str, prefix: str = "narration") -> str:
        text_hash = hashlib.md5(text[:100].encode()).hexdigest()[:8]
        return f"{prefix}_{text_hash}.mp3"
    
    def generate_narration(self, text: str, voice: str = "en-us", 
                          slow: bool = False) -> Optional[str]:
        if not text or not text.strip():
            return None
        
        voice_config = self.voice_options.get(voice, self.voice_options["en-us"])
        
        try:
            tts = gTTS(
                text=text,
                lang=voice_config["lang"],
                tld=voice_config["tld"],
                slow=slow
            )
            
            filename = self._generate_unique_filename(text)
            filepath = os.path.join(self.output_dir, filename)
            
            tts.save(filepath)
            
            return filepath
        except Exception as e:
            print(f"Error generating audio: {e}")
            return None
    
    def generate_scene_narration(self, scene: Dict[str, Any], 
                                voice: str = "en-us",
                                slow: bool = False) -> Optional[str]:
        scene_text = scene.get("text", "")
        if not scene_text:
            return None
        
        scene_id = scene.get("id", 1)
        
        try:
            voice_config = self.voice_options.get(voice, self.voice_options["en-us"])
            
            tts = gTTS(
                text=scene_text,
                lang=voice_config["lang"],
                tld=voice_config["tld"],
                slow=slow
            )
            
            filename = f"scene_{scene_id}_narration.mp3"
            filepath = os.path.join(self.output_dir, filename)
            
            tts.save(filepath)
            
            return filepath
        except Exception as e:
            print(f"Error generating scene narration: {e}")
            return None
    
    def generate_full_story_narration(self, story_text: str, 
                                      voice: str = "en-us",
                                      slow: bool = False) -> Optional[str]:
        if not story_text or not story_text.strip():
            return None
        
        try:
            voice_config = self.voice_options.get(voice, self.voice_options["en-us"])
            
            tts = gTTS(
                text=story_text,
                lang=voice_config["lang"],
                tld=voice_config["tld"],
                slow=slow
            )
            
            filename = "full_story_narration.mp3"
            filepath = os.path.join(self.output_dir, filename)
            
            tts.save(filepath)
            
            return filepath
        except Exception as e:
            print(f"Error generating full story narration: {e}")
            return None
    
    def generate_all_scene_narrations(self, scenes: List[Dict[str, Any]], 
                                      voice: str = "en-us",
                                      slow: bool = False) -> List[Optional[str]]:
        audio_paths = []
        
        for scene in scenes:
            path = self.generate_scene_narration(scene, voice, slow)
            audio_paths.append(path)
        
        return audio_paths
    
    def get_audio_duration_estimate(self, text: str) -> float:
        words = len(text.split())
        words_per_minute = 150
        duration_minutes = words / words_per_minute
        return duration_minutes * 60
    
    def cleanup_audio_files(self):
        try:
            for filename in os.listdir(self.output_dir):
                filepath = os.path.join(self.output_dir, filename)
                if os.path.isfile(filepath):
                    os.remove(filepath)
            return True
        except Exception as e:
            print(f"Error cleaning up audio files: {e}")
            return False
