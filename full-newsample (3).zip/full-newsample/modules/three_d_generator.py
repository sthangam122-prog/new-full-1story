from PIL import Image, ImageDraw, ImageFilter
import numpy as np
import os
import math
import random
from typing import Dict, Any, List, Tuple
import hashlib


class ThreeDGenerator:
    def __init__(self, output_dir: str = "output/animations"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs("output/images", exist_ok=True)
    
    def _get_seed(self, text: str) -> int:
        return int(hashlib.md5(text.encode()).hexdigest()[:8], 16)
    
    def _create_3d_perspective_grid(self, width: int, height: int, 
                                    color: Tuple[int, int, int]) -> Image.Image:
        img = Image.new('RGB', (width, height), (20, 20, 40))
        draw = ImageDraw.Draw(img)
        
        vanishing_point = (width // 2, height // 3)
        
        for i in range(0, width + 100, 50):
            draw.line([vanishing_point, (i, height)], fill=color, width=1)
        
        for i in range(height // 3, height, 30):
            left_x = int(vanishing_point[0] - (i - vanishing_point[1]) * 1.5)
            right_x = int(vanishing_point[0] + (i - vanishing_point[1]) * 1.5)
            draw.line([(max(0, left_x), i), (min(width, right_x), i)], fill=color, width=1)
        
        return img
    
    def _draw_3d_cube(self, draw: ImageDraw.Draw, center: Tuple[int, int], 
                      size: int, color: Tuple[int, int, int], rotation: float = 0):
        offset = int(size * 0.4)
        
        front_face = [
            (center[0] - size//2, center[1] - size//2),
            (center[0] + size//2, center[1] - size//2),
            (center[0] + size//2, center[1] + size//2),
            (center[0] - size//2, center[1] + size//2)
        ]
        
        back_offset_x = int(offset * math.cos(rotation))
        back_offset_y = int(offset * math.sin(rotation) * 0.5)
        
        back_face = [(p[0] + back_offset_x, p[1] - back_offset_y - offset) for p in front_face]
        
        r, g, b = color
        side_color = (max(0, r-50), max(0, g-50), max(0, b-50))
        top_color = (min(255, r+30), min(255, g+30), min(255, b+30))
        
        for i in range(4):
            draw.polygon([front_face[i], front_face[(i+1)%4], 
                         back_face[(i+1)%4], back_face[i]], 
                        fill=side_color, outline=(255, 255, 255))
        
        draw.polygon(back_face, fill=top_color, outline=(255, 255, 255))
        draw.polygon(front_face, fill=color, outline=(255, 255, 255))
    
    def _draw_3d_sphere(self, draw: ImageDraw.Draw, center: Tuple[int, int],
                        radius: int, color: Tuple[int, int, int]):
        for i in range(radius, 0, -2):
            ratio = i / radius
            r = int(color[0] * ratio + 255 * (1 - ratio) * 0.3)
            g = int(color[1] * ratio + 255 * (1 - ratio) * 0.3)
            b = int(color[2] * ratio + 255 * (1 - ratio) * 0.3)
            
            offset = int((radius - i) * 0.2)
            draw.ellipse([center[0] - i + offset, center[1] - i + offset,
                         center[0] + i + offset, center[1] + i + offset],
                        fill=(r, g, b))
        
        highlight_x = center[0] - radius // 3
        highlight_y = center[1] - radius // 3
        draw.ellipse([highlight_x - radius//6, highlight_y - radius//6,
                     highlight_x + radius//6, highlight_y + radius//6],
                    fill=(255, 255, 255, 180))
    
    def _draw_3d_cylinder(self, draw: ImageDraw.Draw, center: Tuple[int, int],
                          width: int, height: int, color: Tuple[int, int, int]):
        r, g, b = color
        
        draw.rectangle([center[0] - width//2, center[1] - height//2,
                       center[0] + width//2, center[1] + height//2],
                      fill=color)
        
        draw.ellipse([center[0] - width//2, center[1] + height//2 - 15,
                     center[0] + width//2, center[1] + height//2 + 15],
                    fill=(max(0, r-40), max(0, g-40), max(0, b-40)))
        
        draw.ellipse([center[0] - width//2, center[1] - height//2 - 15,
                     center[0] + width//2, center[1] - height//2 + 15],
                    fill=(min(255, r+40), min(255, g+40), min(255, b+40)))
    
    def _draw_3d_character(self, draw: ImageDraw.Draw, center: Tuple[int, int],
                           size: int, color: Tuple[int, int, int]):
        head_center = (center[0], center[1] - size)
        head_radius = size // 3
        self._draw_3d_sphere(draw, head_center, head_radius, (255, 218, 185))
        
        body_center = (center[0], center[1])
        self._draw_3d_cylinder(draw, body_center, size//2, size, color)
        
        draw.ellipse([head_center[0] - 8, head_center[1] - 5,
                     head_center[0] - 3, head_center[1] + 2], fill=(50, 50, 50))
        draw.ellipse([head_center[0] + 3, head_center[1] - 5,
                     head_center[0] + 8, head_center[1] + 2], fill=(50, 50, 50))
    
    def generate_3d_render(self, scene: Dict[str, Any], 
                           width: int = 800, height: int = 600) -> str:
        seed = self._get_seed(scene.get("text", str(scene.get("id", 0))))
        random.seed(seed)
        
        grid_color = (50, 50, 80)
        img = self._create_3d_perspective_grid(width, height, grid_color)
        draw = ImageDraw.Draw(img)
        
        characters = scene.get("characters", [])
        num_objects = max(3, len(characters) + 2)
        
        colors = [
            (255, 100, 100), (100, 255, 100), (100, 100, 255),
            (255, 255, 100), (255, 100, 255), (100, 255, 255)
        ]
        
        for i in range(min(num_objects - len(characters), 5)):
            x = random.randint(100, width - 100)
            y = random.randint(height // 2, height - 100)
            size = random.randint(30, 60)
            color = random.choice(colors)
            
            shape_type = random.choice(["cube", "sphere", "cylinder"])
            if shape_type == "cube":
                self._draw_3d_cube(draw, (x, y), size, color, random.random() * 0.5)
            elif shape_type == "sphere":
                self._draw_3d_sphere(draw, (x, y), size // 2, color)
            else:
                self._draw_3d_cylinder(draw, (x, y), size // 2, size, color)
        
        char_spacing = width // (len(characters) + 1) if characters else width // 2
        for i, char in enumerate(characters[:4]):
            x = char_spacing * (i + 1)
            y = height // 2 + 50
            color = colors[i % len(colors)]
            self._draw_3d_character(draw, (x, y), 60, color)
        
        try:
            from PIL import ImageFont
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 24)
        except:
            font = None
        
        title = f"3D Scene {scene.get('id', 1)}"
        draw.rectangle([10, 10, 200, 45], fill=(0, 0, 0, 200))
        draw.text((15, 15), title, fill=(0, 255, 255), font=font)
        
        draw.text((15, height - 30), "3D Render - Story2Scene", fill=(100, 100, 100), font=font)
        
        filename = f"3d_scene_{scene.get('id', 1)}.png"
        filepath = os.path.join("output/images", filename)
        img.save(filepath, "PNG")
        
        return filepath
    
    def generate_animation_frames(self, scene: Dict[str, Any], 
                                  num_frames: int = 30,
                                  width: int = 400, height: int = 300) -> List[Image.Image]:
        seed = self._get_seed(scene.get("text", str(scene.get("id", 0))))
        random.seed(seed)
        
        frames = []
        colors = [(255, 100, 100), (100, 255, 100), (100, 100, 255)]
        
        objects = []
        for i in range(3):
            objects.append({
                "x": width // 4 + i * (width // 4),
                "y": height // 2,
                "size": 40 + i * 10,
                "color": colors[i],
                "speed": 2 + i * 0.5,
                "phase": i * 2 * math.pi / 3
            })
        
        for frame_idx in range(num_frames):
            img = Image.new('RGB', (width, height), (30, 30, 50))
            draw = ImageDraw.Draw(img)
            
            draw.line([(width//2, 0), (width//2, height)], fill=(50, 50, 70), width=1)
            draw.line([(0, height//2), (width, height//2)], fill=(50, 50, 70), width=1)
            
            for obj in objects:
                angle = frame_idx * obj["speed"] * 0.1 + obj["phase"]
                
                y_offset = int(30 * math.sin(angle))
                rotation = angle * 0.5
                
                self._draw_3d_cube(draw, (obj["x"], obj["y"] + y_offset), 
                                  obj["size"], obj["color"], rotation)
            
            characters = scene.get("characters", [])
            if characters:
                char_x = width // 2
                char_y = height - 80
                bob_offset = int(5 * math.sin(frame_idx * 0.3))
                self._draw_3d_character(draw, (char_x, char_y + bob_offset), 40, (100, 150, 255))
            
            try:
                from PIL import ImageFont
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
            except:
                font = None
            
            draw.text((5, 5), f"Frame {frame_idx + 1}/{num_frames}", fill=(150, 150, 150), font=font)
            
            frames.append(img)
        
        return frames
    
    def save_animation_gif(self, scene: Dict[str, Any], 
                           duration: int = 100) -> str:
        frames = self.generate_animation_frames(scene)
        
        filename = f"animation_scene_{scene.get('id', 1)}.gif"
        filepath = os.path.join(self.output_dir, filename)
        
        frames[0].save(
            filepath,
            save_all=True,
            append_images=frames[1:],
            duration=duration,
            loop=0
        )
        
        return filepath
    
    def generate_all_3d_content(self, scenes: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        results = {
            "renders": [],
            "animations": []
        }
        
        for scene in scenes:
            render_path = self.generate_3d_render(scene)
            results["renders"].append(render_path)
            
            anim_path = self.save_animation_gif(scene)
            results["animations"].append(anim_path)
        
        return results
