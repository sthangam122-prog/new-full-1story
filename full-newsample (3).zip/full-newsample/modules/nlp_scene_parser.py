import spacy
from typing import List, Dict, Any
import re

try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    import subprocess
    subprocess.run(["python", "-m", "spacy", "download", "en_core_web_sm"])
    nlp = spacy.load("en_core_web_sm")


class SceneParser:
    def __init__(self):
        self.nlp = nlp
        self.scene_keywords = [
            "meanwhile", "later", "suddenly", "then", "after", "before",
            "next", "finally", "soon", "eventually", "at that moment",
            "the next day", "that night", "in the morning", "at dawn"
        ]
    
    def segment_sentences(self, text: str) -> List[str]:
        doc = self.nlp(text)
        sentences = [sent.text.strip() for sent in doc.sents if sent.text.strip()]
        return sentences
    
    def extract_entities(self, text: str) -> Dict[str, List[str]]:
        doc = self.nlp(text)
        entities = {
            "characters": [],
            "locations": [],
            "objects": [],
            "times": []
        }
        
        for ent in doc.ents:
            if ent.label_ == "PERSON":
                if ent.text not in entities["characters"]:
                    entities["characters"].append(ent.text)
            elif ent.label_ in ["GPE", "LOC", "FAC"]:
                if ent.text not in entities["locations"]:
                    entities["locations"].append(ent.text)
            elif ent.label_ in ["TIME", "DATE"]:
                if ent.text not in entities["times"]:
                    entities["times"].append(ent.text)
        
        for token in doc:
            if token.pos_ == "PROPN" and token.text not in entities["characters"]:
                if not any(token.text in loc for loc in entities["locations"]):
                    entities["characters"].append(token.text)
        
        return entities
    
    def extract_actions(self, text: str) -> List[str]:
        doc = self.nlp(text)
        actions = []
        
        for token in doc:
            if token.pos_ == "VERB" and token.dep_ in ["ROOT", "conj"]:
                action_phrase = self._get_verb_phrase(token)
                if action_phrase and action_phrase not in actions:
                    actions.append(action_phrase)
        
        return actions
    
    def _get_verb_phrase(self, verb_token) -> str:
        phrase_parts = []
        
        for child in verb_token.lefts:
            if child.dep_ in ["nsubj", "nsubjpass"]:
                phrase_parts.append(child.text)
        
        phrase_parts.append(verb_token.text)
        
        for child in verb_token.rights:
            if child.dep_ in ["dobj", "pobj", "attr", "prep"]:
                subtree_text = " ".join([t.text for t in child.subtree])
                phrase_parts.append(subtree_text)
                break
        
        return " ".join(phrase_parts) if len(phrase_parts) > 1 else ""
    
    def detect_scene_breaks(self, sentences: List[str]) -> List[int]:
        scene_breaks = [0]
        
        for i, sentence in enumerate(sentences):
            sentence_lower = sentence.lower()
            
            for keyword in self.scene_keywords:
                if keyword in sentence_lower:
                    if i not in scene_breaks:
                        scene_breaks.append(i)
                    break
            
            if i > 0 and len(sentences) > 3:
                if i % 3 == 0 and i not in scene_breaks:
                    prev_entities = self.extract_entities(sentences[i-1])
                    curr_entities = self.extract_entities(sentence)
                    
                    prev_locs = set(prev_entities["locations"])
                    curr_locs = set(curr_entities["locations"])
                    
                    if curr_locs and prev_locs and not curr_locs.intersection(prev_locs):
                        scene_breaks.append(i)
        
        return sorted(set(scene_breaks))
    
    def create_scenes(self, text: str) -> List[Dict[str, Any]]:
        sentences = self.segment_sentences(text)
        if not sentences:
            return []
        
        scene_breaks = self.detect_scene_breaks(sentences)
        scenes = []
        
        for i, break_idx in enumerate(scene_breaks):
            if i + 1 < len(scene_breaks):
                end_idx = scene_breaks[i + 1]
            else:
                end_idx = len(sentences)
            
            scene_sentences = sentences[break_idx:end_idx]
            scene_text = " ".join(scene_sentences)
            
            if not scene_text.strip():
                continue
            
            entities = self.extract_entities(scene_text)
            actions = self.extract_actions(scene_text)
            
            scene = {
                "id": i + 1,
                "text": scene_text,
                "sentences": scene_sentences,
                "characters": entities["characters"],
                "locations": entities["locations"],
                "times": entities["times"],
                "actions": actions,
                "description": self._generate_scene_description(entities, actions)
            }
            scenes.append(scene)
        
        if not scenes and sentences:
            full_text = " ".join(sentences)
            entities = self.extract_entities(full_text)
            actions = self.extract_actions(full_text)
            scenes.append({
                "id": 1,
                "text": full_text,
                "sentences": sentences,
                "characters": entities["characters"],
                "locations": entities["locations"],
                "times": entities["times"],
                "actions": actions,
                "description": self._generate_scene_description(entities, actions)
            })
        
        return scenes
    
    def _generate_scene_description(self, entities: Dict[str, List[str]], actions: List[str]) -> str:
        parts = []
        
        if entities["locations"]:
            parts.append(f"Setting: {', '.join(entities['locations'][:2])}")
        
        if entities["characters"]:
            parts.append(f"Characters: {', '.join(entities['characters'][:3])}")
        
        if actions:
            parts.append(f"Actions: {', '.join(actions[:3])}")
        
        if entities["times"]:
            parts.append(f"Time: {', '.join(entities['times'][:1])}")
        
        if not parts:
            parts.append("A scene from the story")
        
        return ". ".join(parts)
    
    def parse_story(self, story_text: str) -> Dict[str, Any]:
        story_text = story_text.strip()
        if not story_text:
            return {
                "original_text": "",
                "sentences": [],
                "scenes": [],
                "all_characters": [],
                "all_locations": [],
                "summary": "No story provided"
            }
        
        sentences = self.segment_sentences(story_text)
        scenes = self.create_scenes(story_text)
        
        all_characters = []
        all_locations = []
        for scene in scenes:
            for char in scene["characters"]:
                if char not in all_characters:
                    all_characters.append(char)
            for loc in scene["locations"]:
                if loc not in all_locations:
                    all_locations.append(loc)
        
        return {
            "original_text": story_text,
            "sentences": sentences,
            "scenes": scenes,
            "all_characters": all_characters,
            "all_locations": all_locations,
            "summary": f"Story contains {len(scenes)} scene(s) with {len(all_characters)} character(s)"
        }
