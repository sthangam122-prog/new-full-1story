import os
import sys
from flask import Flask, render_template, request, jsonify, session, send_file, redirect, url_for, flash
from flask_session import Session
import uuid

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules.nlp_scene_parser import SceneParser
from modules.image_generator import ImageGenerator
from modules.three_d_generator import ThreeDGenerator
from modules.audio_generator import AudioGenerator
from modules.scene_manager import SceneManager
from utils.helpers import validate_story_input, truncate_text

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'story2scene-secret-key-' + str(uuid.uuid4()))
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_FILE_DIR'] = '/tmp/flask_session'
app.config['SESSION_PERMANENT'] = False
Session(app)

scene_parser = SceneParser()
image_generator = ImageGenerator()
three_d_generator = ThreeDGenerator()
audio_generator = AudioGenerator()
scene_manager_instance = SceneManager()

SAMPLE_STORY = """Once upon a time in a mystical forest, there lived a young wizard named Elena. She had discovered an ancient spellbook hidden beneath an old oak tree.

One morning, Elena ventured deep into the forest to practice her new spells. The trees whispered secrets as she walked along the winding path.

Suddenly, she encountered a magnificent dragon resting by a crystal-clear lake. The dragon's scales shimmered like emeralds in the sunlight.

"Fear not, young wizard," the dragon spoke with a voice like thunder. "I have been waiting for someone worthy to learn the ancient magic."

Together, they began a journey that would change the kingdom forever. Elena learned the dragon's wisdom, and in return, she shared the joy of friendship."""


def init_session():
    if 'story_text' not in session:
        session['story_text'] = ""
    if 'parsed_data' not in session:
        session['parsed_data'] = None
    if 'scenes' not in session:
        session['scenes'] = []
    if 'current_scene_idx' not in session:
        session['current_scene_idx'] = 0
    if 'generated_images' not in session:
        session['generated_images'] = {}
    if 'generated_audio' not in session:
        session['generated_audio'] = {}
    if 'generated_3d' not in session:
        session['generated_3d'] = {}
    if 'generated_animations' not in session:
        session['generated_animations'] = {}
    if 'full_audio_path' not in session:
        session['full_audio_path'] = None
    if 'art_style' not in session:
        session['art_style'] = "realistic"
    if 'voice_option' not in session:
        session['voice_option'] = "en-us"
    if 'generation_complete' not in session:
        session['generation_complete'] = False


@app.route('/')
def index():
    init_session()
    voices = audio_generator.get_available_voices()
    return render_template('index.html', 
                         sample_story=SAMPLE_STORY,
                         voices=voices,
                         session=session)


@app.route('/analyze', methods=['POST'])
def analyze_story():
    init_session()
    story_text = request.form.get('story_text', '').strip()
    
    if not story_text:
        return jsonify({'success': False, 'error': 'Please enter a story'})
    
    validation = validate_story_input(story_text)
    if not validation["valid"]:
        return jsonify({'success': False, 'error': '\n'.join(validation["errors"])})
    
    try:
        session['story_text'] = story_text
        parsed = scene_parser.parse_story(story_text)
        session['parsed_data'] = parsed
        session['scenes'] = parsed.get("scenes", [])
        session['current_scene_idx'] = 0
        scene_manager_instance.initialize_project(story_text, parsed)
        session.modified = True
        
        return jsonify({
            'success': True,
            'scene_count': len(session['scenes']),
            'characters': parsed.get('all_characters', []),
            'locations': parsed.get('all_locations', [])
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route('/generate', methods=['POST'])
def generate_all():
    init_session()
    story_text = request.form.get('story_text', '').strip()
    art_style = request.form.get('art_style', 'realistic')
    voice_option = request.form.get('voice_option', 'en-us')
    
    if not story_text:
        return jsonify({'success': False, 'error': 'Please enter a story'})
    
    validation = validate_story_input(story_text)
    if not validation["valid"]:
        return jsonify({'success': False, 'error': '\n'.join(validation["errors"])})
    
    session['story_text'] = story_text
    session['art_style'] = art_style
    session['voice_option'] = voice_option
    
    errors = []
    
    try:
        parsed = scene_parser.parse_story(story_text)
        session['parsed_data'] = parsed
        session['scenes'] = parsed.get("scenes", [])
        session['current_scene_idx'] = 0
        scene_manager_instance.initialize_project(story_text, parsed)
    except Exception as e:
        return jsonify({'success': False, 'error': f'Failed to analyze story: {str(e)}'})
    
    total_scenes = len(session['scenes'])
    if total_scenes == 0:
        return jsonify({'success': False, 'error': 'No scenes could be extracted from the story'})
    
    session['generated_images'] = {}
    session['generated_audio'] = {}
    session['generated_3d'] = {}
    session['generated_animations'] = {}
    
    for scene in session['scenes']:
        scene_id = scene.get("id", 1)
        
        try:
            image_path = image_generator.generate_scene_image(scene, art_style)
            session['generated_images'][str(scene_id)] = image_path
            scene_manager_instance.update_scene_assets(scene_id, image_path=image_path)
        except Exception as e:
            errors.append(f"2D image scene {scene_id}: {str(e)}")
        
        try:
            render_path = three_d_generator.generate_3d_render(scene)
            session['generated_3d'][str(scene_id)] = render_path
            scene_manager_instance.update_scene_assets(scene_id, render_3d_path=render_path)
        except Exception as e:
            errors.append(f"3D render scene {scene_id}: {str(e)}")
        
        try:
            anim_path = three_d_generator.save_animation_gif(scene)
            session['generated_animations'][str(scene_id)] = anim_path
            scene_manager_instance.update_scene_assets(scene_id, animation_path=anim_path)
        except Exception as e:
            errors.append(f"Animation scene {scene_id}: {str(e)}")
        
        try:
            audio_path = audio_generator.generate_scene_narration(scene, voice_option)
            if audio_path:
                session['generated_audio'][str(scene_id)] = audio_path
                scene_manager_instance.update_scene_assets(scene_id, audio_path=audio_path)
        except Exception as e:
            errors.append(f"Audio scene {scene_id}: {str(e)}")
    
    try:
        full_audio = audio_generator.generate_full_story_narration(story_text, voice_option)
        session['full_audio_path'] = full_audio
    except Exception as e:
        errors.append(f"Full story audio: {str(e)}")
    
    session['generation_complete'] = True
    session.modified = True
    
    return jsonify({
        'success': True,
        'scene_count': total_scenes,
        'characters': parsed.get('all_characters', []),
        'locations': parsed.get('all_locations', []),
        'errors': errors if errors else None
    })


@app.route('/scene/<int:scene_idx>')
def get_scene(scene_idx):
    init_session()
    scenes = session.get('scenes', [])
    
    if not scenes or scene_idx < 0 or scene_idx >= len(scenes):
        return jsonify({'success': False, 'error': 'Invalid scene index'})
    
    scene = scenes[scene_idx]
    scene_id = str(scene.get('id', scene_idx + 1))
    
    session['current_scene_idx'] = scene_idx
    session.modified = True
    
    return jsonify({
        'success': True,
        'scene': scene,
        'scene_id': scene_id,
        'total_scenes': len(scenes),
        'current_idx': scene_idx,
        'has_image': scene_id in session.get('generated_images', {}),
        'has_3d': scene_id in session.get('generated_3d', {}),
        'has_animation': scene_id in session.get('generated_animations', {}),
        'has_audio': scene_id in session.get('generated_audio', {}),
        'image_path': session.get('generated_images', {}).get(scene_id, ''),
        'render_3d_path': session.get('generated_3d', {}).get(scene_id, ''),
        'animation_path': session.get('generated_animations', {}).get(scene_id, ''),
        'audio_path': session.get('generated_audio', {}).get(scene_id, '')
    })


@app.route('/generate_single/<asset_type>/<int:scene_idx>', methods=['POST'])
def generate_single(asset_type, scene_idx):
    init_session()
    scenes = session.get('scenes', [])
    
    if not scenes or scene_idx < 0 or scene_idx >= len(scenes):
        return jsonify({'success': False, 'error': 'Invalid scene index'})
    
    scene = scenes[scene_idx]
    scene_id = str(scene.get('id', scene_idx + 1))
    art_style = session.get('art_style', 'realistic')
    voice_option = session.get('voice_option', 'en-us')
    
    try:
        if asset_type == 'image':
            path = image_generator.generate_scene_image(scene, art_style)
            session['generated_images'][scene_id] = path
        elif asset_type == '3d':
            path = three_d_generator.generate_3d_render(scene)
            session['generated_3d'][scene_id] = path
        elif asset_type == 'animation':
            path = three_d_generator.save_animation_gif(scene)
            session['generated_animations'][scene_id] = path
        elif asset_type == 'audio':
            path = audio_generator.generate_scene_narration(scene, voice_option)
            if path:
                session['generated_audio'][scene_id] = path
            else:
                return jsonify({'success': False, 'error': 'Failed to generate audio'})
        else:
            return jsonify({'success': False, 'error': 'Invalid asset type'})
        
        session.modified = True
        return jsonify({'success': True, 'path': path})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route('/download/<asset_type>/<int:scene_idx>')
def download_asset(asset_type, scene_idx):
    init_session()
    scenes = session.get('scenes', [])
    
    if scene_idx < 0 or scene_idx >= len(scenes):
        return "Invalid scene", 404
    
    scene_id = str(scenes[scene_idx].get('id', scene_idx + 1))
    
    path_map = {
        'image': session.get('generated_images', {}).get(scene_id),
        '3d': session.get('generated_3d', {}).get(scene_id),
        'animation': session.get('generated_animations', {}).get(scene_id),
        'audio': session.get('generated_audio', {}).get(scene_id)
    }
    
    file_path = path_map.get(asset_type)
    
    if not file_path or not os.path.exists(file_path):
        return "File not found", 404
    
    return send_file(file_path, as_attachment=True)


@app.route('/download/full_audio')
def download_full_audio():
    init_session()
    path = session.get('full_audio_path')
    
    if not path or not os.path.exists(path):
        return "File not found", 404
    
    return send_file(path, as_attachment=True, download_name='full_story_narration.mp3')


@app.route('/download/zip')
def download_zip():
    init_session()
    import zipfile
    import tempfile
    
    try:
        with tempfile.NamedTemporaryFile(mode='wb', suffix='.zip', delete=False) as tmp:
            zip_path = tmp.name
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for scene_id, path in session.get('generated_images', {}).items():
                if path and os.path.exists(path):
                    zf.write(path, f"images/scene_{scene_id}_2d.png")
            
            for scene_id, path in session.get('generated_3d', {}).items():
                if path and os.path.exists(path):
                    zf.write(path, f"3d_renders/scene_{scene_id}_3d.png")
            
            for scene_id, path in session.get('generated_animations', {}).items():
                if path and os.path.exists(path):
                    zf.write(path, f"animations/scene_{scene_id}_animation.gif")
            
            for scene_id, path in session.get('generated_audio', {}).items():
                if path and os.path.exists(path):
                    zf.write(path, f"audio/scene_{scene_id}_narration.mp3")
            
            full_audio = session.get('full_audio_path')
            if full_audio and os.path.exists(full_audio):
                zf.write(full_audio, "audio/full_story_narration.mp3")
        
        if os.path.exists(zip_path):
            return send_file(zip_path, as_attachment=True, download_name='story2scene_export.zip')
        else:
            return "Failed to create ZIP", 500
    except Exception as e:
        return f"Error: {str(e)}", 500


@app.route('/asset/<path:filename>')
def serve_asset(filename):
    file_path = os.path.join('output', filename)
    if os.path.exists(file_path):
        return send_file(file_path)
    return "File not found", 404


@app.route('/clear', methods=['POST'])
def clear_session():
    session.clear()
    return jsonify({'success': True})


@app.route('/settings', methods=['POST'])
def update_settings():
    init_session()
    session['art_style'] = request.form.get('art_style', session.get('art_style', 'realistic'))
    session['voice_option'] = request.form.get('voice_option', session.get('voice_option', 'en-us'))
    session.modified = True
    return jsonify({'success': True})


@app.route('/load_sample', methods=['POST'])
def load_sample():
    init_session()
    session['story_text'] = SAMPLE_STORY
    session.modified = True
    return jsonify({'success': True, 'story': SAMPLE_STORY})


if __name__ == '__main__':
    os.makedirs('/tmp/flask_session', exist_ok=True)
    os.makedirs('output/images', exist_ok=True)
    os.makedirs('output/audio', exist_ok=True)
    os.makedirs('output/animations', exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=False)
